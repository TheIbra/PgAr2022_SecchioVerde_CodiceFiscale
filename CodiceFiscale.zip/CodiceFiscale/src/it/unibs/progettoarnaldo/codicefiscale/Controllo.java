package it.unibs.progettoarnaldo.codicefiscale;

import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.regex.Pattern;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

public class Controllo {

	private ArrayList<String> codiciSbagliati = new ArrayList<String>();
	private ArrayList<String> codiciSpaiati = new ArrayList<String>();
	
	public void controlloSbagliati() {
		
        XMLInputFactory xmlif = null;
		XMLStreamReader xmlr = null;
		try {
			xmlif = XMLInputFactory.newInstance();
			xmlr = xmlif.createXMLStreamReader("src/it/unibs/progettoarnaldo/codicefiscale/codiciFiscali.xml", new FileInputStream("src/it/unibs/progettoarnaldo/codicefiscale/codiciFiscali.xml"));
		} catch (Exception e) {
			System.out.println("Errore nell'inizializzazione del reader:");
			System.out.println(e.getMessage());
		}
		try {
			
			while(xmlr.hasNext())
			{
			    if(xmlr.isCharacters())
			    {
			        String codiceDaControllare = xmlr.getText();
			        if(!valido(codiceDaControllare)) {
			        	codiciSbagliati.add(codiceDaControllare);
			        }
			    }
			    xmlr.next();
			}
		} catch (Exception e) {
			System.out.println("Errore nell'inizializzazione del reader:");
			System.out.println(e.getMessage());
		}
		
	}
	
	public boolean valido(String codice) {
		
		//controllo caratteri e cifre
		int i;
        if(codice.length()!=16) 
            return false;
        for(i=0;i<6;i++){
            if(Pattern.matches("[a-zA-Z]+", String.valueOf(codice.charAt(i))) == false )
                return false;
        }
        if(Pattern.matches("[a-zA-Z]+", String.valueOf(codice.charAt(8))) == false || Pattern.matches("[a-zA-Z]+", String.valueOf(codice.charAt(11))) == false || Pattern.matches("[a-zA-Z]+", String.valueOf(codice.charAt(15))) == false)
        	return false;
        if(Pattern.matches("[0-9]+", String.valueOf(codice.charAt(6))) == false || Pattern.matches("[0-9]+", String.valueOf(codice.charAt(7))) == false || Pattern.matches("[0-9]+", String.valueOf(codice.charAt(9))) == false || 
        		Pattern.matches("[0-9]+", String.valueOf(codice.charAt(10))) == false || Pattern.matches("[0-9]+", String.valueOf(codice.charAt(12))) == false || Pattern.matches("[0-9]+", String.valueOf(codice.charAt(13))) == false || Pattern.matches("[0-9]+", String.valueOf(codice.charAt(14))) == false)
        	return false;
        
       //controllo validit� giorno
        String controlloGiorno = "";
        controlloGiorno += codice.charAt(9); 
		controlloGiorno += codice.charAt(10);
        int giorno = Integer.valueOf(controlloGiorno);
        if(giorno<1||giorno>71)
            return false;
        else if(giorno > 31 && giorno < 41)
        	return false;
        
        //controllo validit� mese
        if(codice.charAt(8)!='A' && codice.charAt(8)!='B' && codice.charAt(8)!='C' && codice.charAt(8)!='D' &&
        		codice.charAt(8)!='E' && codice.charAt(8)!='H' && codice.charAt(8)!='L' && codice.charAt(8)!='M' &&
        		codice.charAt(8)!='P' && codice.charAt(8)!='R' && codice.charAt(8)!='S' && codice.charAt(8)!='T' )
            return false;
        
        //controllo carattere di controllo
        int somma = 0;
		for(int j=0; j<codice.length(); j+=2) {
			switch(codice.charAt(j)) {
			case '0': somma+=1; break;
			case '1': somma+=0; break;
			case '2': somma+=5; break;
			case '3': somma+=7; break;
			case '4': somma+=9; break;
			case '5': somma+=13; break;
			case '6': somma+=15; break;
			case '7': somma+=17; break;
			case '8': somma+=19; break;
			case '9': somma+=21; break;
			case 'A': somma+=1; break;
			case 'B': somma+=0; break;
			case 'C': somma+=5; break;
			case 'D': somma+=7; break;
			case 'E': somma+=9; break;
			case 'F': somma+=13; break;
			case 'G': somma+=15; break;
			case 'H': somma+=17; break;
			case 'I': somma+=19; break;
			case 'J': somma+=21; break;
			case 'K': somma+=2; break;
			case 'L': somma+=4; break;
			case 'M': somma+=18; break;
			case 'N': somma+=20; break;
			case 'O': somma+=11; break;
			case 'P': somma+=3; break;
	    	case 'Q': somma+=6; break;
			case 'R': somma+=8; break;
			case 'S': somma+=12; break;
			case 'T': somma+=14; break;
			case 'U': somma+=16; break;
			case 'V': somma+=10; break;
			case 'W': somma+=22; break;
			case 'X': somma+=25; break;
			case 'Y': somma+=24; break;
			case 'Z': somma+=23; break;
			}
		}
		for(int j=1; j<codice.length(); j+=2) {
			switch(codice.charAt(j)) {
			case '0': somma+=0; break;
			case '1': somma+=1; break;
			case '2': somma+=2; break;
			case '3': somma+=3; break;
			case '4': somma+=4; break;
			case '5': somma+=5; break;
			case '6': somma+=6; break;
			case '7': somma+=7; break;
			case '8': somma+=8; break;
			case '9': somma+=9; break;
			case 'A': somma+=0; break;
			case 'B': somma+=1; break;
			case 'C': somma+=2; break;
			case 'D': somma+=3; break;
			case 'E': somma+=4; break;
			case 'F': somma+=5; break;
			case 'G': somma+=6; break;
			case 'H': somma+=7; break;
			case 'I': somma+=8; break;
			case 'J': somma+=9; break;
			case 'K': somma+=10; break;
			case 'L': somma+=11; break;
			case 'M': somma+=12; break;
			case 'N': somma+=13; break;
			case 'O': somma+=14; break;
			case 'P': somma+=15; break;
			case 'Q': somma+=16; break;
			case 'R': somma+=17; break;
			case 'S': somma+=18; break;
			case 'T': somma+=19; break;
			case 'U': somma+=20; break;
			case 'V': somma+=21; break;
			case 'W': somma+=22; break;
			case 'X': somma+=23; break;
			case 'Y': somma+=24; break;
			case 'Z': somma+=25; break;
			}
		}
		int resto = 0;
		char codiceControllo = '\0';
		resto = somma % 26;
		switch(resto) {
		case 0: codiceControllo='A'; break;
		case 1: codiceControllo='B'; break;
		case 2: codiceControllo='C'; break;
		case 3: codiceControllo='D'; break;
		case 4: codiceControllo='E'; break;
		case 5: codiceControllo='F'; break;
		case 6: codiceControllo='G'; break;
		case 7: codiceControllo='H'; break;
		case 8: codiceControllo='I'; break;
		case 9: codiceControllo='J'; break;
		case 10: codiceControllo='K'; break;
		case 11: codiceControllo='L'; break;
		case 12: codiceControllo='M'; break;
		case 13: codiceControllo='N'; break;
		case 14: codiceControllo='O'; break;
		case 15: codiceControllo='P'; break;
		case 16: codiceControllo='Q'; break;
		case 17: codiceControllo='R'; break;
		case 18: codiceControllo='S'; break;
		case 19: codiceControllo='T'; break;
		case 20: codiceControllo='U'; break;
		case 21: codiceControllo='V'; break;
		case 22: codiceControllo='W'; break;
		case 23: codiceControllo='X'; break;
		case 24: codiceControllo='Y'; break;
		case 25: codiceControllo='Z'; break;
		}
		if(codiceControllo==codice.charAt(15)) 
			return false;
		
		//controllo numero giorni
        
		String controlloGiornoNascita = "";
        controlloGiornoNascita += codice.charAt(9); 
		controlloGiornoNascita += codice.charAt(10);
        int giornoNascita = Integer.valueOf(controlloGiornoNascita); //creo un intero che corrisponde al giorno di nascita
        
        if (codice.charAt(8) == 'A' || codice.charAt(8) == 'C' || codice.charAt(8) == 'E' || codice.charAt(8) == 'L' || codice.charAt(8) == 'M' || codice.charAt(8) == 'R' || codice.charAt(8) == 'T') {
            if (giornoNascita < 1 || giornoNascita > 71)
                return false;
            if (giornoNascita > 31 && giornoNascita < 41)
                return false;
        
        }
        if (codice.charAt(8) == 'B') {
            if (giornoNascita < 1 || giornoNascita > 68)
                return false;
            if (giornoNascita > 28 && giornoNascita < 41)
                return false;
       
        }
        if (codice.charAt(8) == 'D' || codice.charAt(8) == 'H' || codice.charAt(8) == 'S' || codice.charAt(8) == 'P') {
            if (giornoNascita < 1 || giornoNascita > 70)
                return false;
            if (giornoNascita > 30 && giornoNascita < 41)
                return false;          
        }
        
        return true;
	}
}
