package it.unibs.progettoarnaldo.codicefiscale;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.XMLStreamWriter;


public class Output {
	
	private static final String UTF = "utf-8";
	private static final String VERSION = "1.0";
	private static XMLOutputFactory xmlof = null;
	private static XMLStreamWriter xmlw = null;

	/**
	 * Metodo che scrive in output il file codiciPersone.xml	
	 * @param persona
	 * @param codiciSbagliati
	 * @param codiciSpaiati
	 */
	public void ScrittuaOutput(ArrayList<Persona> persona, ArrayList<String> codiciSbagliati, ArrayList<String> codiciSpaiati) {
		try {
			xmlof = XMLOutputFactory.newInstance();
			xmlw = xmlof.createXMLStreamWriter(new FileOutputStream("codiciPersone.xml"), UTF);
			
			xmlw.writeStartDocument(UTF, VERSION);
			xmlw.writeStartElement("output");	
			xmlw.writeStartElement("persone");
			xmlw.writeAttribute("numero", Integer.toString(persona.size()));
			
			for(int i = 0; i<persona.size(); i++) {
				xmlw.writeStartElement("persona");
				xmlw.writeAttribute("id", Integer.toString(i));
				
				xmlw.writeStartElement("nome");
				xmlw.writeCharacters(persona.get(i).getNome());
				xmlw.writeEndElement();
				
				xmlw.writeStartElement("cognome");
				xmlw.writeCharacters(persona.get(i).getCognome());
				xmlw.writeEndElement();
				
				xmlw.writeStartElement("sesso");
				xmlw.writeCharacters(persona.get(i).getSesso());
				xmlw.writeEndElement();
				
				xmlw.writeStartElement("comune_nascita");
				xmlw.writeCharacters(persona.get(i).getComune());
				xmlw.writeEndElement();
				
				xmlw.writeStartElement("data_nascita");
				xmlw.writeCharacters(persona.get(i).getData());
				xmlw.writeEndElement();
				
				xmlw.writeStartElement("codice_fiscale");
				XMLInputFactory xmlif = null;
				XMLStreamReader xmlr = null;
				boolean presente = false;
				try {
					xmlif = XMLInputFactory.newInstance();
					xmlr = xmlif.createXMLStreamReader("src/it/unibs/progettoarnaldo/codicefiscale/codiciFiscali.xml", new FileInputStream("src/it/unibs/progettoarnaldo/codicefiscale/codiciFiscali.xml"));
				} catch (Exception e) {
					System.out.println("Errore nell'inizializzazione del reader:");
					System.out.println(e.getMessage());
				}
				
				while(xmlr.hasNext()) {

					while(!(xmlr.isStartElement() && xmlr.getLocalName().equals("codice")))
	                {
	                    xmlr.next();
	                }
	                xmlr.next();
	                if(persona.get(i).getCodiceFiscale().equals(xmlr.getText())) {
	                	presente = true;
	                	break;
	                }
	                xmlr.next();
					xmlw.writeEndElement();
				}
				
				if(!presente)
					xmlw.writeCharacters("ASSENTE");
				xmlw.writeEndElement();
			}
			xmlw.writeEndElement();
			
			xmlw.writeStartElement("codici");
			xmlw.writeStartElement("invalidi");
			xmlw.writeAttribute("numero", Integer.toString(codiciSbagliati.size()));
			
			for(int i = 0; i<codiciSbagliati.size(); i++) {
				xmlw.writeStartElement("codice");
				xmlw.writeCharacters(codiciSbagliati.get(i));
				xmlw.writeEndElement();
			}
			xmlw.writeEndElement();
			
			xmlw.writeStartElement("spaiati");
			xmlw.writeAttribute("numero", Integer.toString(codiciSpaiati.size()));
			
			for(int i = 0; i<codiciSpaiati.size(); i++) {
				xmlw.writeStartElement("codice");
				xmlw.writeCharacters(codiciSpaiati.get(i));
				xmlw.writeEndElement();
			}
			xmlw.writeEndElement();
			
			xmlw.writeEndElement();
			xmlw.writeEndElement();
			
		} catch (Exception e) {
			System.out.println("Errore nella scrittura del file");
		}
	}
}

