package it.unibs.progettoarnaldo.codicefiscale;

public class Persona {
	
	private int id;
    private String nome;
    private String cognome;
    private String sesso;
    private String comune;
    private String data;
    private String codiceFiscale;

    //Metodo costruttore
	public Persona(int id, String nome, String cognome, String sesso, String comune, String data, String codiceFiscale) {
		this.id = id;
		this.nome = nome;
		this.cognome = cognome;
		this.sesso = sesso;
		this.comune = comune;
		this.data = data;
		this.codiceFiscale = codiceFiscale;
	}

	//Metodi getter e Setter
	public int getId() {
		return id;
	}

	public String getNome() {
		return nome;
	}

	public String getCognome() {
		return cognome;
	}

	public String getSesso() {
		return sesso;
	}

	public String getComune() {
		return comune;
	}

	public String getData() {
		return data;
	}
	public String getCodiceFiscale() {
		return codiceFiscale;
	}
    
  
    
}
