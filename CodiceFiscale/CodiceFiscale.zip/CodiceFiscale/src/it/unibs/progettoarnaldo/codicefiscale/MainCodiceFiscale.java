package it.unibs.progettoarnaldo.codicefiscale;

import java.io.FileInputStream;
import java.util.ArrayList;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

public class MainCodiceFiscale {

	public static void main(String[] args) throws XMLStreamException{

		int id = 0;
	    String nome = "";
	    String cognome = "";
	    String sesso = "";
	    String comune = "";
	    String data = "";
	    CodiceFiscale codiceFiscale = new CodiceFiscale();
	    String codice = "";
	    ArrayList<Persona> persona = new ArrayList<Persona>();
	    Output output = new Output();
	    Controllo controllo = new Controllo();

	    
		XMLInputFactory xmlif = null;
		XMLStreamReader xmlr = null;
		
		//Lettura del file inputPersone.xml
		try {
			xmlif = XMLInputFactory.newInstance();
			xmlr = xmlif.createXMLStreamReader("src/it/unibs/progettoarnaldo/codicefiscale/inputPersone.xml", new FileInputStream("src/it/unibs/progettoarnaldo/codicefiscale/inputPersone.xml"));
		} catch (Exception e) {
			System.out.println("Errore nell'inizializzazione del reader:");
			System.out.println(e.getMessage());
		}
			
		try {
			while(xmlr.hasNext()) {
				
				if(xmlr.isStartElement() && xmlr.getLocalName().equals("persona")) {  
					
					while(!(xmlr.isStartElement() && xmlr.getLocalName().equals("nome")))
	                {
	                    xmlr.next();
	                }
	                xmlr.next();
	                nome = xmlr.getText();
	            
	                while(!(xmlr.isStartElement() && xmlr.getLocalName().equals("cognome")))
	                {
	                    xmlr.next();
	                }
	                xmlr.next();
	                cognome = xmlr.getText();
	        
	                while(!(xmlr.isStartElement() && xmlr.getLocalName().equals("sesso")))
	                {
	                    xmlr.next();
	                }
	                xmlr.next();
	                sesso = xmlr.getText();
	       
	                while(!(xmlr.isStartElement() && xmlr.getLocalName().equals("comune_nascita")))
	                {
	                    xmlr.next();
	                }
	                xmlr.next();
	                comune = xmlr.getText();
	
	                while(!(xmlr.isStartElement() && xmlr.getLocalName().equals("data_nascita")))
	                {
	                    xmlr.next();
	                }
	                xmlr.next();
	                data = xmlr.getText();
					
	                
					codice=codiceFiscale.creaCodiceFiscale(nome, cognome, sesso, comune, data);								
					persona.add(new Persona(id, nome, cognome, sesso, comune, data, codice));				
					id++;
					
						
				}
				else xmlr.next();
			}
		}
		 catch (Exception e)
        {
            System.out.println("Errore: non esiste una nuova riga da leggere");
        }
		
		controllo.controlloSbagliati();
		controllo.controlloSpaiati(controllo.getCodiciGiusti(), persona);
		//chiamata del metodo per scrivere il file codiciPersone.xml
		output.ScrittuaOutput(persona, controllo.getCodiciSbagliati(), controllo.getCodiciSpaiati());
	}

}
