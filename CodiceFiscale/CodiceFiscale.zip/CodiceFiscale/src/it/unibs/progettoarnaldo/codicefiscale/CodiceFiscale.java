package it.unibs.progettoarnaldo.codicefiscale;

import java.io.FileInputStream;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

public class CodiceFiscale {
	
	/**
	 * Metodo per creare un codice fiscale con le informazioni lette dal file inputPersone.xml
	 * @param nome
	 * @param cognome
	 * @param sesso
	 * @param comune
	 * @param data
	 * @return codice fiscale
	 * @throws XMLStreamException
	 */
	public String creaCodiceFiscale(String nome, String cognome, String sesso, String comune, String data) throws XMLStreamException {
		
		String codice = "";
		
		//calcolo del cognome
		int cnt=0;
		for(int i=0; i<cognome.length(); i++) {
			if(cognome.charAt(i) != 'A' && cognome.charAt(i) != 'E' && cognome.charAt(i) != 'I' && cognome.charAt(i) != 'U' && cognome.charAt(i) != 'O' ) {
				cnt++;
				codice+=cognome.charAt(i);
			}
			if(cnt==3) {
				break;
			}
		}
		if(cnt!=3) {
			for(int i=0; i<cognome.length(); i++) {
				if(cognome.charAt(i) == 'A' && cognome.charAt(i) == 'E' && cognome.charAt(i) == 'I' && cognome.charAt(i) == 'U' && cognome.charAt(i) == 'O' ) {
					cnt++;
					codice+=cognome.charAt(i);
				}
				if(cnt==3) {
					break;
				}
			}
		}	
		if(cnt==2) {
			codice+='X';
		}
		
		//calcolo del nome
		cnt=0;
		for(int i=0; i<nome.length(); i++) {
			if(nome.charAt(i) != 'A' && nome.charAt(i) != 'E' && nome.charAt(i) != 'I' && nome.charAt(i) != 'U' && nome.charAt(i) != 'O' ) {
				cnt++;
				if(cnt!=2) {
					codice+=nome.charAt(i);
				}
			}
			if(cnt==4) {
				break;
			}
		}
		if(cnt!=4) {
			for(int i=0; i<cognome.length(); i++) {
				if(nome.charAt(i) == 'A' && nome.charAt(i) == 'E' && nome.charAt(i) == 'I' && nome.charAt(i) == 'U' && nome.charAt(i) == 'O' ) {
					cnt++;
					codice+=nome.charAt(i);
				}
				if(cnt==3) {
					break;
				}
			}
		}	
		if(cnt==2) {
			codice+='X';
		}
		
		//calcolo anno
		codice+=data.charAt(2);
		codice+=data.charAt(3);
		
		//calcolo mese
		String mese = "";
		mese+=data.charAt(5);
		mese+=data.charAt(6);
		if(mese.equals("01")) {
			codice+='A';
		}
		else if(mese.equals("02")) {
			codice+='B';
		}
		else if(mese.equals("03")) {
			codice+='C';
		}
		else if(mese.equals("04")) {
			codice+='D';
		}
		else if(mese.equals("05")) {
			codice+='E';
		}
		else if(mese.equals("06")) {
			codice+='H';
		}
		else if(mese.equals("07")) {
			codice+='L';
		}
		else if(mese.equals("08")) {
			codice+='M';
		}
		else if(mese.equals("09")) {
			codice+='P';
		}
		else if(mese.equals("10")) {
			codice+='R';
		}
		else if(mese.equals("11")) {
			codice+='S';
		}
		else if(mese.equals("12")) {
			codice+='T';
		}
		else {
			System.out.println("ci sono errori !?�");
		}
		
		//calcolo giorno
		if(sesso.equals("M")) {
			String giorno = "";
			giorno+=data.charAt(8);
			giorno+=data.charAt(9);
			codice.concat(giorno);
		}
		else {
			String giorno = "";
			giorno+=data.charAt(8);
			giorno+=data.charAt(9);
			Integer conversione = Integer.valueOf(giorno);
			conversione+=40;
			giorno = String.valueOf(conversione);	
			codice.concat(giorno);
		}
		
		//calcolo comune
		XMLInputFactory xmlif = null;
		XMLStreamReader xmlr = null;
		try {
			xmlif = XMLInputFactory.newInstance();
			xmlr = xmlif.createXMLStreamReader("src/it/unibs/progettoarnaldo/codicefiscale/comuni.xml", new FileInputStream("src/it/unibs/progettoarnaldo/codicefiscale/comuni.xml"));
		} catch (Exception e) {
			System.out.println("Errore nell'inizializzazione del reader:");
			System.out.println(e.getMessage());
		}
		
		while(xmlr.hasNext())
        {
            if(xmlr.isCharacters() && xmlr.getText().equals(comune))
            {
                while(!(xmlr.isStartElement() && xmlr.getLocalName().equals("codice")))
                {
                    xmlr.next();
                }
                xmlr.next();
                codice.concat(xmlr.getText());
            }
            else xmlr.next();
        }
        
		
		//calcolo carattere di controllo
		int somma = 0;
		for(int i=0; i<codice.length(); i+=2) {
			switch(codice.charAt(i)) {
				case '0': somma+=1; break;
				case '1': somma+=0; break;
				case '2': somma+=5; break;
				case '3': somma+=7; break;
				case '4': somma+=9; break;
				case '5': somma+=13; break;
				case '6': somma+=15; break;
				case '7': somma+=17; break;
				case '8': somma+=19; break;
				case '9': somma+=21; break;
				case 'A': somma+=1; break;
				case 'B': somma+=0; break;
				case 'C': somma+=5; break;
				case 'D': somma+=7; break;
				case 'E': somma+=9; break;
				case 'F': somma+=13; break;
				case 'G': somma+=15; break;
				case 'H': somma+=17; break;
				case 'I': somma+=19; break;
				case 'J': somma+=21; break;
				case 'K': somma+=2; break;
				case 'L': somma+=4; break;
				case 'M': somma+=18; break;
				case 'N': somma+=20; break;
				case 'O': somma+=11; break;
				case 'P': somma+=3; break;
		    	case 'Q': somma+=6; break;
				case 'R': somma+=8; break;
				case 'S': somma+=12; break;
				case 'T': somma+=14; break;
				case 'U': somma+=16; break;
				case 'V': somma+=10; break;
				case 'W': somma+=22; break;
				case 'X': somma+=25; break;
				case 'Y': somma+=24; break;
				case 'Z': somma+=23; break;
			}
		}
		for(int i=1; i<codice.length(); i+=2) {
			switch(codice.charAt(i)) {
				case '0': somma+=0; break;
				case '1': somma+=1; break;
				case '2': somma+=2; break;
				case '3': somma+=3; break;
				case '4': somma+=4; break;
				case '5': somma+=5; break;
				case '6': somma+=6; break;
				case '7': somma+=7; break;
				case '8': somma+=8; break;
				case '9': somma+=9; break;
				case 'A': somma+=0; break;
				case 'B': somma+=1; break;
				case 'C': somma+=2; break;
				case 'D': somma+=3; break;
				case 'E': somma+=4; break;
				case 'F': somma+=5; break;
				case 'G': somma+=6; break;
				case 'H': somma+=7; break;
				case 'I': somma+=8; break;
				case 'J': somma+=9; break;
				case 'K': somma+=10; break;
				case 'L': somma+=11; break;
				case 'M': somma+=12; break;
				case 'N': somma+=13; break;
				case 'O': somma+=14; break;
				case 'P': somma+=15; break;
				case 'Q': somma+=16; break;
				case 'R': somma+=17; break;
				case 'S': somma+=18; break;
				case 'T': somma+=19; break;
				case 'U': somma+=20; break;
				case 'V': somma+=21; break;
				case 'W': somma+=22; break;
				case 'X': somma+=23; break;
				case 'Y': somma+=24; break;
				case 'Z': somma+=25; break;
			}
		}
		int resto = 0;
		resto = somma % 26;
		switch(resto) {
			case 0: codice+='A'; break;
			case 1: codice+='B'; break;
			case 2: codice+='C'; break;
			case 3: codice+='D'; break;
			case 4: codice+='E'; break;
			case 5: codice+='F'; break;
			case 6: codice+='G'; break;
			case 7: codice+='H'; break;
			case 8: codice+='I'; break;
			case 9: codice+='J'; break;
			case 10: codice+='K'; break;
			case 11: codice+='L'; break;
			case 12: codice+='M'; break;
			case 13: codice+='N'; break;
			case 14: codice+='O'; break;
			case 15: codice+='P'; break;
			case 16: codice+='Q'; break;
			case 17: codice+='R'; break;
			case 18: codice+='S'; break;
			case 19: codice+='T'; break;
			case 20: codice+='U'; break;
			case 21: codice+='V'; break;
			case 22: codice+='W'; break;
			case 23: codice+='X'; break;
			case 24: codice+='Y'; break;
			case 25: codice+='Z'; break;
		}
			
		return codice;
	}
	
}
